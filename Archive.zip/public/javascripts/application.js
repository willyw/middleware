// $(document).ready(function(){
// 	
// 	$("#uploadify").uploadify({
// 		'uploader'       : '/swf/uploadify.swf',
// 		'script'         : $("#new_product").attr('action'),
// 		'cancelImg'      : '/images/cancel.png',
// 		'folder'         : 'uploads',
// 		'queueID'        : 'fileQueue', // if you specify this, need to provide script with <div id="fileQueue"></div>
// 		'auto'           : true,
// 		'multi'          : true,
// 		'scriptAccess'   : 'always',
// 	});
// });