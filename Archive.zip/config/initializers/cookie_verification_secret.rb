# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = 'a0a2acb626b82e466f59c13602b902686190251157023ba04ad384cc39b05f33f0dbea1c1abae461c813959ece381cbbcf4268fb0a21f11e55c3f06d2bbfdc99';
